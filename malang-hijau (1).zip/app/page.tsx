import { Logo } from "@/components/logo"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Link from "next/link"
import { MobileContainer } from "@/components/mobile-container"

export default function SignInPage() {
  return (
    <MobileContainer>
      <section className="flex flex-col gap-6 items-center justify-center px-6 py-10 flex-1">
        <Logo className="w-16 h-16" />
        <h1 className="text-2xl font-bold">Malang Hijau</h1>

        <div className="w-full space-y-4 mt-4">
          <Input
            placeholder="Username"
            className="w-full px-4 py-3 rounded-xl border border-stone-300 focus:ring-2 focus:ring-secondary"
          />
          <Input
            type="password"
            placeholder="Password"
            className="w-full px-4 py-3 rounded-xl border border-stone-300 focus:ring-2 focus:ring-secondary"
          />
          <Button asChild className="w-full py-3 rounded-xl bg-primary text-white font-semibold">
            <Link href="/dashboard">Sign In</Link>
          </Button>
        </div>
      </section>
    </MobileContainer>
  )
}
